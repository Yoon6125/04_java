package com.javatest.rpc;

import java.util.Scanner;

public class Rpc {

	public static void main(String[] args) {
		Rpc_run a = new Rpc_run();

		a.run();

	}

}
