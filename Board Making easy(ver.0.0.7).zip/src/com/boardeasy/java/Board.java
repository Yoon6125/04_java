package com.boardeasy.java;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	private ArrayList<Post> p = new ArrayList<Post>();
	private int con_num = 0;

	void board_run() {
		Scanner sc = new Scanner(System.in);
		loop_xx: while (true) {
			System.out.println("-------------계시판 v.0.0.7------------------------------------------");
			System.out.println("1.글 목록/2. 글 읽기/ 3. 글 쓰기/4. 글삭제/ 5.글 수정/ x.종료 ");
			System.out.println("--------------------------------------------------------");

			String choose = sc.next();

			switch (choose) {
			case "1":
				for (Post p : p) {
//					p.info();
//					p.toString();
					System.out.println(p);
				}
				break;
			case "2":
				System.out.println("읽을 글을 선택:");
				int c = sc.nextInt();
				for (int i = 0; i < p.size(); i++) {
					Post e = p.get(i);
					if (e.getNo() == c) {
						e.read_content();
					}
				}
				break;
			case "3":
				System.out.println("글 제목:");
				String title = sc.next();
				System.out.println("글 내용:");
				String content = sc.next();
				System.out.println("글 작성자:");
				String writer = sc.next();
				con_num = con_num + 1;
				int a = con_num;

				Post a1 = new Post(a, title, content, writer);
				p.add(a1);

				break;
			case "4":
				System.out.println("삭제할 글을 선택:");
				int c1 = sc.nextInt();
				int index_num = 0;
				for (int i = 0; i < p.size(); i++) {
					Post e = p.get(i);
					if (e.getNo() == c1) {
						index_num = index_num + 1;
						break;
					}
				}
				p.remove(index_num);
				break;
			case "5":
				System.out.println("수정할 글을 선택:");
				int c2 = sc.nextInt();

				for (int i = 0; i < p.size(); i++) {
					Post e = p.get(i);
					if (e.getNo() == c2) {
						System.out.println("수정 내용 작성");
						String u = sc.next();
						e.setContent(u);
					}
				}
				break;
			case "x":
				break loop_xx;
			default:
				break;
			}

		}

	}
}
