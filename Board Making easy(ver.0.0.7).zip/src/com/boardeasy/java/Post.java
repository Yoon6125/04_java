package com.boardeasy.java;

public class Post {
	private int no;
	private String title;
	private String content;
	private String writer;

	public Post(int no, String title, String content, String writer) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}

//	void info() {
//		System.out.println(no + ". 제목: " + title + "글쓴이: " + writer);
//		
//	}

	void read_content() {
		System.out.println(content);
	}

	public int getNo() {
		return no;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	// 객체 주소 출력 대신 String.format 내용 출력
	@Override
	public String toString() {
		String s = String.format("제목: %s  작성자: %s", title, writer);
		return s;
	}

}
