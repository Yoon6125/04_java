package com.rpg.java;

public class Create_user_mob {
	Mob mob1 = new Mob("1", 500, 100);
	Character user1 = new Character("달렉", "기사", 200, 100, 40);
	Armor a = new Armor();
	Wepon w = new Wepon();

	void create_Item() {

		a.name = "방어구";
		a.dp = 30;

		w.name = "무기";
		w.wepon_damage = 100;

	}

	void add_item_box() {

		Item.it.add(w);
		Item.it.add(a);
	}

}
