package com.rpg.java;

import java.util.Scanner;

public class Battle extends Create_user_mob {
	void battle_logic() {
		System.out.println("전투개시");
		Scanner sc = new Scanner(System.in);
//		mob1.hp = super.mob1.hp;

		loop_xx: while (true) {
			System.out.println("공격:1      방어:2");
			int dis = sc.nextInt();
			int user_damage = user1.attack_point + w.wepon_damage;
			int user_defence = user1.dp + a.dp;
			int user_damage_random = ((int) (Math.random() * user_damage + 1));
			int mob_damage_random = (int) (Math.random() * (mob1.attack_point - user_defence) + 1);
			int Mob_hp_left;
			int user_hp_left;

			create_Item();

			switch (dis) {
			case 1:
				System.out.print(user1.name + "의 공격");
				System.out.println(mob1.name + "은/는" + user_damage_random + "의 피해를 입었다");
				w.use_item();

				System.out.print(mob1.name + "의 공격");
				System.out.println(user1.name + "은/는" + mob_damage_random + "의 피해를 입었다");
				a.use_item();

				user_hp_left = user1.hp - mob_damage_random;
				Mob_hp_left = mob1.hp - user_damage_random;

				user1.hp = user_hp_left;
				mob1.hp = Mob_hp_left;
				System.out.println(mob1.name + "의 남은 체력:" + Mob_hp_left);
				System.out.println(user1.name + "의 남은 체력:" + user_hp_left);

				if (Mob_hp_left < 0) {
					System.out.println(user1.name + "의 승리");
					Mob_hp_left = 0;
					Mob_hp_left = super.mob1.hp;
					break loop_xx;
				} else if (user_hp_left < 0) {
					System.out.println(user1.name + "은/는 쓰러젔다");
					break loop_xx;
				}

				break;

			case 2:
				System.out.print(mob1.name + "의 공격");
				System.out.println(user1.name + "은/는" + mob_damage_random + "의 피해를 입었다");
				a.use_item();
				user_hp_left = user1.hp - mob_damage_random;
				Mob_hp_left = mob1.hp;
				user1.hp = user_hp_left;
				mob1.hp = Mob_hp_left;
				System.out.println(mob1.name + "의 남은 체력:" + Mob_hp_left);
				System.out.println(user1.name + "의 남은 체력:" + user_hp_left);

				if (Mob_hp_left < 0) {
					System.out.println(user1.name + "의 승리");
					break loop_xx;
				} else if (user_hp_left < 0) {
					System.out.println(user1.name + "은/는 쓰러젔다");
					break loop_xx;
				}
				break;
			}

		}

	}
}
