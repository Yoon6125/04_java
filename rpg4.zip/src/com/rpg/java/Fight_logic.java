package com.rpg.java;

import java.util.Scanner;

public class Fight_logic extends Create_user_mob {
	Battle b = new Battle();

	Scanner sc = new Scanner(System.in);

	void fight_run() {
		user1.status();
		loop_xx: while (true) {
			mob1.use();
			System.out.println("전투한다:1    도망친다 :2");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				b.battle_logic();
				break loop_xx;
			case 2:
				System.out.println("성공적으로 도망쳤다!");
				break loop_xx;

			}

		}

	}

}
