package com.Boardtest.data.java;

import java.util.ArrayList;

public class Data {
	static public ArrayList<Post> post1 = new ArrayList<>();

}
