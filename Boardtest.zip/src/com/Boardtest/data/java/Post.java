package com.Boardtest.data.java;

import java.time.LocalDate;

public class Post {
	static int no;
	public int post_no;
	public String post_name;
	public String writer;
	public String post_content;
	public int content_hit;
	public String date;

	public Post(String post_name, String writer, String post_content, int content_hit) {
		no = no + 1;
		post_no = no;
		this.post_name = post_name;
		this.writer = writer;
		this.post_content = post_content;
		this.content_hit = content_hit;
		LocalDate d = LocalDate.now();
		date = d.toString();
	}

	public void info() {
		System.out.print("글번호: " + post_no);
		System.out.print("글 제목: " + post_name);
		System.out.print("작성자: " + writer);
		System.out.print("조회수: " + content_hit);
		System.out.println("작성일: " + date);
	}

}
