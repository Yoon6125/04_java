package com.Boardtest.main.java;

import com.Boardtest.util.java.Ci;

public class Boardobj {
	void boradobj_run() {

		loop: while (true) {
			String choose_num = Ci.r("입력");
			Boardwrite w = new Boardwrite();
			Boardlist l = new Boardlist();
			switch (choose_num) {
			case "1":
				l.show_list();
				break;

			case "2":
				break;
			case "3":
				w.write_procss();
				break;
			case "4":
				break;
			case "x":
				break loop;
			default:

				break;
			}

		}

	}
}
