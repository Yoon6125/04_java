package com.Boardtest.main.java;

import com.Boardtest.data.java.Data;
import com.Boardtest.data.java.Post;

public class Boardlist {
	void show_list() {
		for (Post p : Data.post1) {
			p.info();
		}

	}
}
