package com.Boardtest.main.java;

public class Main {

	public static void main(String[] args) {
		System.out.println("[1.글 리스트/2.글 읽기/3.글 쓰기/4.글 삭제/x.종료]");
		Boardobj obj = new Boardobj();
		obj.boradobj_run();
	}

}
