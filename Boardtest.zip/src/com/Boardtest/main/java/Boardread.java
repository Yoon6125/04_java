package com.Boardtest.main.java;

import com.Boardtest.data.java.Data;
import com.Boardtest.data.java.Post;
import com.Boardtest.util.java.Ci;

public class Boardread {
	void content_read() {
		System.out.println("글 번호 선택:");
		int num_read = Ci.i();
		String read;
		for (Post p : Data.post1) {
//			if(num_read==p.post_no) {
//			
//			}
			for (int i = 0; i < Data.post1.size(); i++) {

			}
		}

	}
}
