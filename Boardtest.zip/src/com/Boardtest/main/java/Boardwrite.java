package com.Boardtest.main.java;

import com.Boardtest.data.java.Data;
import com.Boardtest.data.java.Post;
import com.Boardtest.util.java.Ci;

public class Boardwrite {
	public void write_procss() {

		String title;
		while (true) {
			title = Ci.rl("글 제목");
			if (title.length() > 0) {
				break;
			} else {
				System.out.println("제목 쓰셈");
			}

		}
		String content;
		while (true) {
//			System.out.println("글 내용:");
			content = Ci.rl("글 내용");
			if (content.length() > 0) {
				break;
			} else {
				System.out.println("글 쓰셈");
			}
		}
		String writer_name;
		while (true) {
//			System.out.println("작성자:");
			writer_name = Ci.rl("작성자");
			if (writer_name.length() > 0) {
				break;
			} else {
				System.out.println("작성자 쓰셈");
			}
		}

		Post p = new Post(title, writer_name, content, 0);

		Data.post1.add(p);
		System.out.println("글 작성 완료");
	}
}
