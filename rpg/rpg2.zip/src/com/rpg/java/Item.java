package com.rpg.java;

public class Item {

}
