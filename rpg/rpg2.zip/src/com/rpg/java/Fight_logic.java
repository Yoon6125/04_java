package com.rpg.java;

public class Fight_logic {

	void fight_run() {
		Create_user_mob.mob1.use();
		while (true) {
			int user_damage_random = (int) (Math.random() * Create_user_mob.user1.attack_point + 1);
			int mob_damage_random = (int) (Math.random() * Create_user_mob.mob1.attack_point + 1);
			System.out.print(Create_user_mob.user1.name + "의 공격");
			System.out.println(Create_user_mob.mob1.name + "은/는" + user_damage_random + "의 피해를 입었다");
			int Mob_hp_left = Create_user_mob.mob1.hp - user_damage_random;

			System.out.print(Create_user_mob.mob1.name + "의 공격");
			System.out.println(Create_user_mob.user1.name + "은/는" + mob_damage_random + "의 피해를 입었다");

			int user_hp_left = Create_user_mob.user1.hp - (mob_damage_random - Create_user_mob.user1.dp);

			if (Mob_hp_left == 0) {
				System.out.println(Create_user_mob.user1.name + "의 승리");
				break;
			} else if (user_hp_left == 0) {
				System.out.println(Create_user_mob.user1.name + "은/는 쓰러젔다");
				break;
			} else {
				System.out.printf(Create_user_mob.mob1.name + "의 남은 체력:" + Mob_hp_left);
				System.out.printf(Create_user_mob.user1.name + "의 남은 체력:" + user_hp_left);
			}

		}

	}

}
