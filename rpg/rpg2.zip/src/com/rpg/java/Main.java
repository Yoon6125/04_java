package com.rpg.java;

public class Main {

	public static void main(String[] args) {
		Fight_logic f = new Fight_logic();

		f.fight_run();
	}

}
