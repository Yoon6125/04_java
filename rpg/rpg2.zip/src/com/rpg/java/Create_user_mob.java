package com.rpg.java;

public class Create_user_mob {
	static Mob mob1 = new Mob("1", 500, 100);
	static Character user1 = new Character("달렉", "기사", 200, 100, 40);
}
