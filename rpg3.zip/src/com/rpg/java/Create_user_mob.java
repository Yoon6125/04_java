package com.rpg.java;

public class Create_user_mob {
	Mob mob1 = new Mob("1", 500, 100);
	Character user1 = new Character("달렉", "기사", 200, 100, 80);
}
