package com.rpg.java;

public class Fight_logic extends Create_user_mob {

	void fight_run() {
		mob1.use();
		while (true) {

			int user_damage_random = ((int) (Math.random() * user1.attack_point + 1));
			int mob_damage_random = (int) (Math.random() * (mob1.attack_point - user1.dp) + 1);
			System.out.print(user1.name + "의 공격");
			System.out.println(mob1.name + "은/는" + user_damage_random + "의 피해를 입었다");
			int Mob_hp_left = mob1.hp - user_damage_random;

			System.out.print(mob1.name + "의 공격");
			System.out.println(user1.name + "은/는" + mob_damage_random + "의 피해를 입었다");

			int user_hp_left = user1.hp - mob_damage_random;
			user1.hp = user_hp_left;
			mob1.hp = Mob_hp_left;
			if (Mob_hp_left < 0) {
				System.out.println(user1.name + "의 승리");
				break;
			} else if (user_hp_left < 0) {
				System.out.println(user1.name + "은/는 쓰러젔다");
				break;
			} else {
				System.out.println(mob1.name + "의 남은 체력:" + Mob_hp_left);
				System.out.println(user1.name + "의 남은 체력:" + user_hp_left);
			}
		}

	}

}
