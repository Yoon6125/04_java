package com.rpg.java;

public class Item {
	String name;
	static int use_num = 100; // 내구도, 사용횟수

	void use_item() {
		use_num = use_num - 1;
	}
}
