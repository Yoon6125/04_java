package com.rpg.java;

public class user_mob {
	String name;
}
