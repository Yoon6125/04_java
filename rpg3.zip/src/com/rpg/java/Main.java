package com.rpg.java;

public class Main {

	public static void main(String[] args) {
//		Create_user r = new Create_user("달렉", "기사", 200, 100, 50);
		Fight_logic f = new Fight_logic();

		f.fight_run();

		Armor a = new Armor();
		a.dp = 30;

		Wepon w = new Wepon();
		w.wepon_damage = 300;
		for (int i = 0; i < 10; i++) {
			a.use_item();
			w.use_item();

		}
//		Armor a = new Armor();s
//		a.dp = 10;
//		a.use_num = 30;

//		int user_dp = r.dp + a.dp;

//		System.out.println(Create_user_mob.user1.name + "의 방어도 = " + user_dp);

	}

}
