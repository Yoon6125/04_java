package com.test.pj;

import java.util.HashSet;
import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
//		HashMap<String, String> a = new HashMap<>();
//
//		a.put("1", "고양이");
//		a.put("2", "개");
//
//		String r = a.get("1");
//		a.get("2");
//
//		System.out.println(r);
//		
//		Hashtable<String, String> b= new Hashtable<>();
//		b.put("1", "고양이1");
//		b.put("2", "개1");

		// Hashset 사용 로또 추첨기 코드 예제(이전 버전에 비해 코드 단순)
		HashSet<Integer> hs = new HashSet<>();
		int r = 0;
		while (true) {
			r = (int) (Math.random() * 45 + 1);
			hs.add(r);
			if (hs.size() == 6) {
				break;
			}
		}

		Iterator<Integer> it = hs.iterator();
		System.out.println("while, next() 로 꺼내기");
		while (it.hasNext()) {
			int s = it.next();
			System.out.println(s + " ");
		}

	}

}
