package com.boardeasy.java;

public class Main {

	public static void main(String[] args) {
		Board b = new Board();
		b.board_run();
	}

}
