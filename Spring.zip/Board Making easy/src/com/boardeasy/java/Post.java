package com.boardeasy.java;

public class Post {
	int no;
	String title;
	String content;
	String writer;

	public Post(int no, String title, String content, String writer) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}

	void info() {
		System.out.println(no + ". 제목: " + title + "글쓴이: " + writer);
	}

	void read_content() {
		System.out.println(content);
	}

}
