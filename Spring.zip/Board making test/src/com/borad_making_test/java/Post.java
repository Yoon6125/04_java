package com.borad_making_test.java;

public class Post {
//	int no;
	int num;
	String title;
	String content;
	String writer;

	public Post(int num, String title, String content, String writer) {
//		no = no + 1;
		this.num = num;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}

	void info() {
		String s = String.format("글번호: %d 제목: %s 작성자: %s", num, title, writer);
		System.out.println(s);
	}

	void info_forread() {
		String s = String.format(" 제목: %s 작성자: %s", title, writer);
		System.out.println(s);
		System.out.println("-----------------------------------------");
		System.out.println(content);
		System.out.println("-----------------------------------------");
	}
}
