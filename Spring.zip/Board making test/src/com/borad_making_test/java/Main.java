package com.borad_making_test.java;

public class Main {

	public static void main(String[] args) {
		Board b = new Board();
		b.run();
	}

}
