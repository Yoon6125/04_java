package com.boardmtest.java;

import java.util.Scanner;

public class Board_fix {
	void boardfix_run() {
		Scanner sc = new Scanner(System.in);
		System.out.println("수정할 글을 선택해주세요");
		int choose = sc.nextInt();

		for (int i = 0; i < Board.p.size(); i++) {
			Post p = Board.p.get(i);
			if (p.con_num == choose) {
				System.out.println("글을 다시 작성해주세요");
				String re_con = sc.next();
				p.content = re_con;
				break;
			}

		}
	}
}
