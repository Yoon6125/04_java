package com.boardmtest.java;

public class Board_list {
	void boardlist_run() {
		for (Post p : Board.p) {
			p.info();
		}
	}
}
