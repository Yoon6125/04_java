package com.boardmtest.java;

import java.util.Scanner;

public class Board_write {

	void boardwrite_run() {

		Scanner sc = new Scanner(System.in);
		System.out.println("글 제목: ");
		String tt = sc.next();
		System.out.println("글 내용: ");
		String con = sc.next();
		System.out.println("글 작성자: ");
		String wt = sc.next();

		Post po = new Post(tt, con, wt);
		Board.p.add(po);

		System.out.println("글 작성됨");
	}
}
