package com.boardmtest.java;

public class Post {
	static int no;
	int con_num;
	String title;
	String content;
	String writer;

	public Post(String title, String content, String writer) {
		no = no + 1;
		con_num = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}

	public void info() {
		System.out.print("글 번호: " + con_num);
		System.out.print("글 제목: " + title);
		System.out.println("글 작성자: " + writer);

	}

	public void content_read() {
		System.out.println("----------------------------------------------------");
		System.out.println(content);
		System.out.println("----------------------------------------------------");
	}

}
