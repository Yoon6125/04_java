package com.boardmtest.java;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	static public ArrayList<Post> p = new ArrayList<Post>();

	void Board_run() {
		Scanner sc = new Scanner(System.in);
		Board_write w = new Board_write();
		Board_list l = new Board_list();
		Board_read r = new Board_read();
		Board_delete d = new Board_delete();
		Board_fix f = new Board_fix();
		while (true) {
			System.out.println("1. 글 리스트 / 2. 글 읽기 / 3. 글 쓰기 /4. 글 삭제/ 5. 글 수정/ x. 종료");
			String choose = sc.next();
			switch (choose) {
			case "1":
				l.boardlist_run();
				break;
			case "2":
				// 글 읽기
				r.boardread_run();
				break;
			case "3":
				w.boardwrite_run();
				break;
			case "4":
				// 글 삭제
				d.boarddelete_run();
				break;
			case "5":
				// 글 수정
				f.boardfix_run();
				break;
			default:
				break;
			}

		}
	}
}
