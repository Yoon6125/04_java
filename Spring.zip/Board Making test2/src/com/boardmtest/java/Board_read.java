package com.boardmtest.java;

import java.util.Scanner;

public class Board_read {
	void boardread_run() {
		Scanner sc = new Scanner(System.in);
		System.out.println("읽으실 글을 선택해주세요");
		int choose = sc.nextInt();
		for (Post p : Board.p) {
			if (p.con_num == choose) {
				p.content_read();
				break;
			}
		}
	}
}
