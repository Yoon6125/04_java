package com.boardmtest.java;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Board b = new Board();

		b.Board_run();
	}

}
