package com.boardmtest.java;

import java.util.Scanner;

public class Board_delete {
	void boarddelete_run() {
		Scanner sc = new Scanner(System.in);
		System.out.println("삭제할 글을 선택해주세요");
		int choose = sc.nextInt();
		int indexchoose = 0;
		for (int i = 0; i < Board.p.size(); i++) {
			Post p = Board.p.get(i);
			if (p.con_num == choose) {

				break;
			} else {
				indexchoose = indexchoose + 1;
			}
		}
		Board.p.remove(indexchoose);

	}
}
