package com.inher.java;

public class Main {

	public static void main(String[] args) {
		Grandfather g = new Grandfather();
		g.name = "2";
		g.age = 111;
		Father f = new Father();
		f.name = "3";
		f.age = 55;
		f.Father_a = "11";
		f.Father_b = "12";
		Child c = new Child();
		c.name = "1";
		c.age = 22;
		c.Father_a = "22";
		c.Father_b = "23";
		g.do_work_1();
		c.do_work_1();

	}

}
