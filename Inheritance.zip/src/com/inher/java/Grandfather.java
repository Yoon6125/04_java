package com.inher.java;

public class Grandfather {
	String name;
	int age;

	public Grandfather(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public Grandfather(String name) {
		super();
		this.name = name;
	}

	public Grandfather(int age) {
		super();
		this.age = age;
	}

	public Grandfather() {
		super();
	}

	void do_work_1() {
		System.out.println(name);

	}

}
