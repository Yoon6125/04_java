package com.inher.java;

public class Father extends Grandfather {
	String Father_a;
	String Father_b;
}
