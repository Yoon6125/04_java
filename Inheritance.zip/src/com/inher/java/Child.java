package com.inher.java;

public class Child extends Father {
	void do_work_1() {
		System.out.println("상속 실험");
	}
}
