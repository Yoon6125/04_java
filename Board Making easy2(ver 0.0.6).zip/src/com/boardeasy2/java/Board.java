package com.boardeasy2.java;

import java.util.ArrayList;
import java.util.Scanner;

public class Board {
	static ArrayList<Post> p = new ArrayList<Post>();

	void Board_run() {
		int n = 0;
		Scanner sc = new Scanner(System.in);
		loop_xx: while (true) {
			System.out.println("----------------------------------------------------------");
			System.out.println("1.글 목록 /2. 글 읽기 /3.글 쓰기 /4.글 삭제/5. 글 수정/ x. 종료  ");
			System.out.println("----------------------------------------------------------");
			String choose = sc.next();

			switch (choose) {
			case "1":
				for (Post p : p) {
					p.info();
				}
				break;
			case "2":
				System.out.println("읽을 글을 선택: ");
				int ch = sc.nextInt();
				for (Post p : p) {
					if (p.getPost_no() == ch) {
						p.readcontent();
					}
				}
				break;
			case "3":
				System.out.println("제목: ");
				String t = sc.next();
				System.out.println("글 내용: ");
				String c = sc.next();
				System.out.println("작성자: ");
				String w = sc.next();
				n = n + 1;
				Post p1 = new Post(n, t, c, w);

				p.add(p1);

				break;
			case "4":
				System.out.println("삭제할 글을 선택: ");
				int ch1 = sc.nextInt();
				int indexnum = 0;
				for (Post p : p) {
					if (p.getPost_no() == ch1) {
						indexnum += 1;
						break;
					}
				}
				p.remove(indexnum);

				break;
			case "5":
				System.out.println("수정할 글을 선택: ");
				int ch3 = sc.nextInt();
				for (Post p : p) {
					if (p.getPost_no() == ch3) {
						System.out.println("수정할 내용으로 입력해주세요:");
						String sg = sc.next();
						p.setContent(sg);
					}
				}

				break;
			case "x":

				break loop_xx;
			default:
				break;

			}
		}

	}
}
