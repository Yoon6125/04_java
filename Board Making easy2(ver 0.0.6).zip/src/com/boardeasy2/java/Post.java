package com.boardeasy2.java;

public class Post {
	private int post_no;
	private String title;
	private String content;
	private String writer;

	public Post(int post_no, String title, String content, String writer) {
		this.post_no = post_no;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}

	void info() {
		System.out.println(post_no + " 제목:" + title + " 글쓴이:" + writer);

	}

	void readcontent() {
		System.out.println(content);
	}

	public int getPost_no() {
		return post_no;
	}

	public void setPost_no(int post_no) {
		this.post_no = post_no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

}
