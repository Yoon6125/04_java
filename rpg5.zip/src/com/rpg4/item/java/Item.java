package com.rpg4.item.java;

import java.util.ArrayList;

public class Item {
	public String name;
	public static ArrayList<Item> it = new ArrayList<Item>();
	static int use_num = 100; // 내구도, 사용횟수

	void use_item() {
		use_num = use_num - 1;
	}
}
