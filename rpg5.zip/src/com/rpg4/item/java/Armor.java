package com.rpg4.item.java;

public class Armor extends Item {
	public int weight;
	public int dp;

	public void use_item() {
		int char_weight = 0;
		char_weight += this.weight;
		int char_dp = 0;
		char_dp += this.dp;

		int armor_num = Item.use_num - 3;
		Item.use_num = armor_num;
		if (armor_num < 0) {
			System.out.println("장비가 파괴되었습니다");
			char_weight = 0;
		} else {
			System.out.println("장비의 현재 내구도: " + armor_num);
		}
	}
}
