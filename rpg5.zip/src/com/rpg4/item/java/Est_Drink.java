package com.rpg4.item.java;

public class Est_Drink extends Item {
	public int hp;

	@Override
	public void use_item() {
		int est_num = use_num - 20;

		if (est_num < 0) {
			System.out.println("물약 부족");
		} else {
			System.out.println("잔여량: " + est_num);
		}
	}
}
