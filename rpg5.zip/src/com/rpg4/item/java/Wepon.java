package com.rpg4.item.java;

public class Wepon extends Item {
	public int wepon_damage;

	@Override
	public void use_item() {
		int wepon_use_num = Item.use_num - 2;
		Item.use_num = wepon_use_num;
		if (wepon_use_num < 0) {
			System.out.println("무기가 파괴되었습니다.");
		} else {
			System.out.println("무기의 현재 내구도: " + wepon_use_num);
		}
	}
}
