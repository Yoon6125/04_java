package com.rpg.java;

import java.util.Scanner;

public class Battle {
	void battle_logic() {
		System.out.println("전투개시");
		Scanner sc = new Scanner(System.in);
//		mob1.hp = super.mob1.hp;
		Use_logic us = new Use_logic();
		Create_user_mob cm = new Create_user_mob();
//		ArrayList<Create_user_mob> cu= new ArrayList<Create_user_mob>();
		loop_xx: while (true) {
			System.out.println("공격:1      방어:2     장비사용:3");
			int dis = sc.nextInt();

			int user_damage = cm.ch.get(0).attack_point;
			System.out.println(user_damage);
			int user_defence = 1;
			int user_damage_random = ((int) (Math.random() * user_damage + 1));
			int mob_damage_random = (int) (Math.random() * (cm.mob1.attack_point - user_defence) + 1);
			int Mob_hp_left;
			int user_hp_left;
			switch (dis) {
			case 1:
				System.out.print(cm.user1.name + "의 공격");
				System.out.println(cm.mob1.name + "은/는" + user_damage_random + "의 피해를 입었다");
				cm.w.use_item();

				System.out.print(cm.mob1.name + "의 공격");
				System.out.println(cm.user1.name + "은/는" + mob_damage_random + "의 피해를 입었다");
				cm.a.use_item();

				user_hp_left = cm.user1.hp - mob_damage_random;
				Mob_hp_left = cm.mob1.hp - user_damage_random;

				cm.user1.hp = user_hp_left;
				cm.mob1.hp = Mob_hp_left;
				System.out.println(cm.mob1.name + "의 남은 체력:" + Mob_hp_left);
				System.out.println(cm.user1.name + "의 남은 체력:" + user_hp_left);

				if (Mob_hp_left < 0) {
					System.out.println(cm.user1.name + "의 승리");
					Mob_hp_left = 0;
					Mob_hp_left = cm.mob1.hp;
					break loop_xx;
				} else if (user_hp_left < 0) {
					System.out.println(cm.user1.name + "은/는 쓰러젔다");
					break loop_xx;
				}

				break;

			case 2:
				System.out.print(cm.mob1.name + "의 공격");
				System.out.println(cm.user1.name + "은/는" + mob_damage_random + "의 피해를 입었다");
				cm.a.use_item();
				user_hp_left = cm.user1.hp - mob_damage_random;
				Mob_hp_left = cm.mob1.hp;
				cm.user1.hp = user_hp_left;
				cm.mob1.hp = Mob_hp_left;
				System.out.println(cm.mob1.name + "의 남은 체력:" + Mob_hp_left);
				System.out.println(cm.user1.name + "의 남은 체력:" + user_hp_left);

				if (Mob_hp_left < 0) {
					System.out.println(cm.user1.name + "의 승리");
					break loop_xx;
				} else if (user_hp_left < 0) {
					System.out.println(cm.user1.name + "은/는 쓰러젔다");
					break loop_xx;
				}
				break;

			case 3:
				loop_xy: while (true) {
					System.out.println("무기 장착:1     방어구 장착:2    회복물약:3");
					int item_choose = sc.nextInt();
					switch (item_choose) {
					case 1:
						us.use_wepon();
						break loop_xy;

					case 2:
						us.use_armor();
						break loop_xy;

					case 3:
						us.use_est();
						break loop_xy;
					}

				}
			}

		}

	}
}
