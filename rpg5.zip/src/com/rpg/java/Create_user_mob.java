package com.rpg.java;

import java.util.ArrayList;

import com.rpg4.item.java.Armor;
import com.rpg4.item.java.Est_Drink;
import com.rpg4.item.java.Item;
import com.rpg4.item.java.Wepon;

public class Create_user_mob {
	ArrayList<Mob> b = new ArrayList<>();
	ArrayList<G_Character> ch = new ArrayList<>();
	Mob mob1 = new Mob("1", 500, 100);
	G_Character user1 = new G_Character("달렉", "기사", 200, 100, 40);

	Armor a = new Armor();
	Wepon w = new Wepon();
	Est_Drink e = new Est_Drink();

	void user_mob_create() {
		b.add(mob1);

		ch.add(user1);
	}

	void create_Item() {

		a.name = "방어구";
		a.dp = 30;

		w.name = "무기";
		w.wepon_damage = 100;

		e.name = "회복약";
		e.hp = 100;

	}

	void add_item_box() {

		Item.it.add(w);
		Item.it.add(a);
	}

	public void user_health() {
		ch.get(user1.hp);
	}

	public void user_dp() {
		ch.get(user1.dp);
	}

	public void user_at() {
		ch.get(user1.attack_point);
	}

}
