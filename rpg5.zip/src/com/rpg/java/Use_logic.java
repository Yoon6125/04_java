package com.rpg.java;

public class Use_logic extends Create_user_mob {

	void use_wepon() {
		create_Item();
		int use_wp = user1.attack_point + w.wepon_damage;
		user1.attack_point = use_wp;
		w.use_item();
		System.out.println(user1.name + "무기를 장착함");
	}

	void use_armor() {
		create_Item();
		int use_ap = user1.dp + a.dp;
		user1.dp = use_ap;
		a.use_item();
		System.out.println(user1.name + "방어구 장착함");
	}

	void use_est() {
		create_Item();
		int heal = user1.hp + e.hp;
		user1.hp = heal;
		e.use_item();
		System.out.println(user1.name + "은/는" + e.hp + "만큼 회복함");
	}

}
