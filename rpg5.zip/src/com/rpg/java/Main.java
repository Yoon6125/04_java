package com.rpg.java;

import java.text.DecimalFormat;

import com.rpg4.item.java.Item;

public class Main {

	public static void main(String[] args) {
//		Create_user r = new Create_user("달렉", "기사", 200, 100, 50);

//		System.out.println(it);

		System.out.print("인벤토리 목록:");
		for (int i = 0; i < Item.it.size(); i++) {
			System.out.print(Item.it.get(i).name);
		}

		Fight_logic f = new Fight_logic();

		f.fight_run();

		DecimalFormat df = new DecimalFormat("#,###");
		System.out.println(df.format(10000000));
//		a.use_item();
//		w.use_item();

//		Armor a = new Armor();s
//		a.dp = 10;
//		a.use_num = 30;

//		int user_dp = r.dp + a.dp;

//		System.out.println(Create_user_mob.user1.name + "의 방어도 = " + user_dp);

	}

}
