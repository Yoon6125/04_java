package com.boardeasy.java;

public class Main {

	public static void main(String[] args) {
		Board b = Board.getInstance();
		b.board_run();
	}

}
