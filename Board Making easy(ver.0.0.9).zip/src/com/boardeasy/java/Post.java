package com.boardeasy.java;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Post {
	private int no;
	private String title;
	private String content;
	private String writer;
	private String write_time;

	public Post(int no, String title, String content, String writer) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;

		// 현제 시간을 가저와서 일정시간 포맷
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		// wirte_time 에 저장
		write_time = sdf.format(now);

	}

//	void info() {
//		System.out.println(no + ". 제목: " + title + "글쓴이: " + writer);
//		
//	}

	String nowtime() {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		// wirte_time 에 저장
		write_time = sdf.format(now);
		return write_time;
	}

	void read_content() {
		System.out.println("----------------------------------------------");
		System.out.println(content);
	}

	public int getNo() {
		return no;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getWrite_time() {
		return write_time;
	}

	public void setWrite_time(String write_time) {
		this.write_time = write_time;
	}

	// 객체 주소 출력 대신 String.format 내용 출력
	@Override
	public String toString() {
		String s = String.format("글번호:%d  제목: %s  작성자: %s  작성일: %s", no, title, writer, write_time);
		return s;
	}

}
