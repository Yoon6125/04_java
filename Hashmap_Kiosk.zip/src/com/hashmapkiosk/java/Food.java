package com.hashmapkiosk.java;

public class Food {
	String name;
	boolean food_con;
	int price;

	public Food(String name, boolean food_con, int price) {
		this.name = name;
		this.food_con = food_con;
		this.price = price;
	}

}
