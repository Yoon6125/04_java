package com.hashmapkiosk.java;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// todo
		// hashmap
		// 음식 리스트 등록
		// 음식 검색
		HashMap<Integer, Food> foods = new HashMap<>();
		ArrayList<Food> fo = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		foods.put(1, new Food("라면", true, 3500));
		foods.put(2, new Food("냉면", false, 5500));
		foods.put(3, new Food("쫄면", false, 5500));
		foods.put(4, new Food("우육면", true, 5500));
		foods.put(5, new Food("자장면", true, 5500));
		foods.put(6, new Food("울면", true, 5500));
		foods.put(7, new Food("해장국", true, 5500));
		foods.put(8, new Food("곰탕", true, 5500));
		foods.put(9, new Food("육개장", true, 5500));

//		Food f1 = new Food("라면", true, 3500);
//		Food f2 = new Food("냉면", false, 5500);

		loop_xx: while (true) {
			System.out.println("===================키오스크 v.0.4===========================");
			System.out.println("1.음식 주문 / 2. 음료주문 / 3. 디저트 주문 /4. 종료");
			System.out.println("==========================================================");
			int choose = sc.nextInt();
			switch (choose) {
			case 1:

				System.out.println("음식 메뉴를 선택해주세요");
				for (int i = 1; i < foods.size() + 1; i++) {
					Food choice = foods.get(i);
					System.out.print(i + ".");
					System.out.println(choice.name);
				}
				int choose1 = sc.nextInt();

				for (int r = 1; r < foods.size() + 1; r++) {
					if (choose1 == r) {
						Food foodItem = foods.get(r);
						fo.add(foodItem);
//					System.out.println(foodItem);
						System.out.println("주문하신 음식은: " + foodItem.name);
						System.out.println("주문하신 음식 가격은: " + foodItem.price);
						if (foodItem.food_con == true) {
							System.out.println("주문하신 음식의 상태는: 뜨거움");
						} else {
							System.out.println("주문하신 음식의 상태는: 차가움");
						}

					}
					if (choose1 == 0) {
						break;
					}
				}
				break;
			case 2:
				System.out.println("개발중");
				break;
			case 3:
				System.out.println("개발중");
				break;
			case 4:
				break loop_xx;
			}
		}

//		// hashmap 모든 데이터 한꺼번에 추출 2
//		for (Map.Entry<Integer, Food> entry : foods.entrySet()) {
//			Integer key = entry.getKey();
//			Food f = entry.getValue();
//			System.out.println(f.name);
//		}

		int total_budget = 0;
		String total;
		for (int j = 0; j < fo.size(); j++) {
			total_budget += fo.get(j).price;
		}
		System.out.println("주문 가격: " + total_budget);

	}

}
