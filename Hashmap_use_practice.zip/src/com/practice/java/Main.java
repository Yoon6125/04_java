package com.practice.java;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		HashMap<Integer, User_char> uc = new HashMap<>();

		uc.put(1, new User_char("달렉", "기사"));
		uc.put(2, new User_char("조지아", "시민"));
		uc.put(3, new User_char("고담", "시티"));
		uc.put(4, new User_char("곡그", "수륙양용"));
		uc.put(5, new User_char("족그", "양면"));
		uc.put(6, new User_char("아타리", "게임기"));
		uc.put(7, new User_char("자바", "커피원두"));

		int a = (int) (Math.random() * (uc.size() + 1));
		Scanner sc = new Scanner(System.in);

		System.out.println("랜덤 뽑기");
		System.out.println("뽑는다: o      안뽑는다: x");

		String choose = sc.next();

		switch (choose) {
		case "o":
			System.out.println("뽑기 결과: " + uc.get(a).name);
			System.out.println("뽑은 내용: " + uc.get(a).job);
			break;

		case "x":
			System.out.println("종료");
			break;
		}

	}

}
