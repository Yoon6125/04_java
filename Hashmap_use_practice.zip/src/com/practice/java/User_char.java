package com.practice.java;

public class User_char {
	String name;
	String job;

	public User_char(String name, String job) {
		this.name = name;
		this.job = job;
	}

}
