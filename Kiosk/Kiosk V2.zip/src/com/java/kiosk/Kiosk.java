package com.java.kiosk;

import java.util.ArrayList;

import java.util.Scanner;

import com.java.kiosk.util.*;

public class Kiosk {
	void run() {
		Product a= new Product("라면", 1000);
		Product b= new Product("김밥", 2000);
		Product c= new Product("뜨아", 1000);
		Product d= new Product("아아", 2000);
		Product e= new Product("타르트", 1000);
		Product f= new Product("마카롱", 1000);
		
		ArrayList<Product> list= new ArrayList<Product>();
		
		
		Scanner sc = new Scanner(System.in);
		Display d1= new Display();
		
		loop_i: while(true) {
			
			d1.title();
			System.out.println("1.식사  2.음료  3.디저트");
			System.out.println("숫자 선택");
			
			String choose =sc.next();
			
			switch (choose) {
			case "1": 
				System.out.println("식사를 선택");
				loop_x: while(true) {
					System.out.println("=====================");
					System.out.print("1."); 
					a.info();
					System.out.print("2.");
					b.info();
					String menu =sc.next();
					switch(menu){
					case "1":
						System.out.println("라면이 선택됨");
						list.add(a);
//						m_list.add(a.price);
						break;
					case "2":
						System.out.println("김밥이 선택됨");
						list.add(b);
//						m_list.add(b.price);
						break;
					case "x":
						break loop_x;
					}
				}
				
			case "2":
				System.out.println("음료를 선택");
				loop_y:while(true) {
					System.out.println("=====================");
					System.out.print("1."); 
					c.info();
					System.out.print("2.");
					d.info();
					String menu =sc.next();
					switch(menu){
					case "1":
						System.out.println("뜨아 선택됨");
						list.add(c);
//						m_list.add(c.price);
						break;
					case "2":
						System.out.println("아아 선택됨");
						list.add(d);
//						m_list.add(d.price);
						break;
					case "x":
						break loop_y;
					}
					
				}
				
			case "3":
				System.out.println("디저트를 선택");
				loop_z:while(true) {
					System.out.println("=====================");
					System.out.print("1."); 
					e.info();
					System.out.print("2.");
					f.info();
					String menu =sc.next();
					switch(menu){
					case "1":
						System.out.println("타르트이 선택됨");
						list.add(e);
//						m_list.add(e.price);
						break;
					case "2":
						System.out.println("마카롱이 선택됨");
						list.add(f);
//						m_list.add(f.price);
						break;
					case "x":
						break loop_z;
					}
					
				}
				
			case "x":{
				break loop_i;
			}
			
		}
	}
		//주문개수 및 주문한 물품 가격 연산
		System.out.println("주문 개수:" +list.size());
		System.out.println("====================주문 목록=================");
		for(int i=0; i<list.size(); i++) {
			System.out.print(list.get(i).name);
			System.out.println("    가격:"+list.get(i).price);
		}
		System.out.println("============================================");
		System.out.println("=====================총 주문 가격================");
		int sum=0;
		for(int i=0;i<list.size();i++ ) {
			sum+=list.get(i).price;
		}
		System.out.println(sum+"원");
		System.out.println("==================================================");
		
		System.out.print("결제");
		System.out.print("     결제 취소:x 입력");
	
		String ch =sc.next();
		if(ch=="x") {
			list.clear();
			if(list.isEmpty()) {
				System.out.println("장바구니가 비었음");
			}
			
		}
}
}
	