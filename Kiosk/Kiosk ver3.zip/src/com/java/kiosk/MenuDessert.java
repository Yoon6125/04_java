package com.java.kiosk;

import java.util.Scanner;

import com.java.kiosk.util.So;

public class MenuDessert {
	void run_dessert() {
		So.ln("디저트를 선택");
		Scanner sc = new Scanner(System.in);
		loop_z: while (true) {
			System.out.println("=====================");
			System.out.print("1.");
			Kiosk.e.info();
			System.out.print("2.");
			Kiosk.f.info();
			String menu = sc.next();
			switch (menu) {
			case "1":
				System.out.println("타르트이 선택됨");
				Kiosk.list.add(Kiosk.e);
//				m_list.add(e.price);
				break;
			case "2":
				System.out.println("마카롱이 선택됨");
				Kiosk.list.add(Kiosk.f);
//				m_list.add(f.price);
				break;
			case "x":
				break loop_z;
			}

		}
	}
}
