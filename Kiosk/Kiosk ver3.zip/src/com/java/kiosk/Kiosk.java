package com.java.kiosk;

import java.util.ArrayList;
import java.util.Scanner;

import com.java.kiosk.util.So;

public class Kiosk {
	static Product a = new Product("라면", 1000);
	static Product b = new Product("김밥", 2000);
	static Product c = new Product("뜨아", 1000);
	static Product d = new Product("아아", 2000);
	static Product e = new Product("타르트", 1000);
	static Product f = new Product("마카롱", 1000);
	static ArrayList<Product> list = new ArrayList<Product>();
	MenuFood food = new MenuFood();
	MenuDrink drink = new MenuDrink();
	MenuDessert dessert = new MenuDessert();
	Total_order total = new Total_order();

	void run() {

		Scanner sc = new Scanner(System.in);
		Display dis = new Display();
		loop_i: while (true) {

			dis.title();
			So.ln("1.식사  2.음료  3.디저트");
			So.ln("숫자 선택");
//			System.out.println("숫자 선택");

			String choose = sc.next();

			switch (choose) {
			case "1":
				food.run_food();
			case "2":
				drink.run_dirnk();

			case "3":
				dessert.run_dessert();

			case "x": {
				break loop_i;
			}

			}
		}
		total.order_run();
		System.out.print("결제");
		System.out.print("     결제 취소:x 입력");

//		String ch = sc.next();
//		if (ch == "x") {
//			list.clear();
//			if (list.isEmpty()) {
//				System.out.println("장바구니가 비었음");
//			}
//
//		}
	}
}
