package com.java.kiosk;

import java.util.Scanner;

public class MenuDrink {
	void run_dirnk() {
		System.out.println("음료를 선택");
		Scanner sc = new Scanner(System.in);
		loop_y: while (true) {
			System.out.println("=====================");
			System.out.print("1.");
			Kiosk.c.info();
			System.out.print("2.");
			Kiosk.d.info();
			String menu = sc.next();
			switch (menu) {
			case "1":
				System.out.println("뜨아 선택됨");
				Kiosk.list.add(Kiosk.c);
//				m_list.add(c.price);
				break;
			case "2":
				System.out.println("아아 선택됨");
				Kiosk.list.add(Kiosk.d);
//				m_list.add(d.price);
				break;
			case "x":
				break loop_y;
			}

		}
	}
}
