package com.java.kiosk;

public class Total_order {
	void order_run() {
		// 주문개수 및 주문한 물품 가격 연산
		System.out.println("주문 개수:" + Kiosk.list.size());
		System.out.println("====================주문 목록=================");
		for (int i = 0; i < Kiosk.list.size(); i++) {
			System.out.print(Kiosk.list.get(i).name);
			System.out.println("    가격:" + Kiosk.list.get(i).price);
		}
		System.out.println("============================================");
		System.out.println("=====================총 주문 가격================");
		int sum = 0;
		for (int i = 0; i < Kiosk.list.size(); i++) {
			sum += Kiosk.list.get(i).price;
		}
		System.out.println(sum + "원");
		System.out.println("==================================================");

	}
}
