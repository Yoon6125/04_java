package com.java.kiosk;

import java.util.Scanner;

public class MenuFood {
	void run_food() {
		System.out.println("식사를 선택");
		Scanner sc = new Scanner(System.in);
		loop_x: while (true) {
			System.out.println("=====================");
			System.out.print("1.");
			Kiosk.a.info();
			System.out.print("2.");
			Kiosk.b.info();
			String menu = sc.next();
			switch (menu) {
			case "1":
				System.out.println("라면이 선택됨");
				Kiosk.list.add(Kiosk.a);
//				m_list.add(a.price);
				break;
			case "2":
				System.out.println("김밥이 선택됨");
				Kiosk.list.add(Kiosk.b);
//				m_list.add(b.price);
				break;
			case "x":
				break loop_x;
			}
		}
	}
}
